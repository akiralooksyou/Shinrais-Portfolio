"use client"

import { useEffect, useState, useRef } from "react"
import { Users, Play, Star, Trophy, Code, Clock } from "lucide-react"

const stats = [
  {
    icon: Users,
    value: 15000000,
    suffix: "+",
    label: "Toplam Oyuncu",
    format: true
  },
  {
    icon: Play,
    value: 150000000,
    suffix: "+",
    label: "Toplam Ziyaret",
    format: true
  },
  {
    icon: Star,
    value: 4.8,
    suffix: "/5",
    label: "Ortalama Puan",
    format: false
  },
  {
    icon: Trophy,
    value: 25,
    suffix: "+",
    label: "Tamamlanan Proje",
    format: false
  },
  {
    icon: Code,
    value: 100000,
    suffix: "+",
    label: "Satır Kod",
    format: true
  },
  {
    icon: Clock,
    value: 5,
    suffix: "+",
    label: "Yıl Deneyim",
    format: false
  },
]

function formatNumber(num: number): string {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(0) + "M"
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(0) + "K"
  }
  return num.toString()
}

function useCountUp(end: number, duration: number = 2000, startCounting: boolean) {
  const [count, setCount] = useState(0)
  
  useEffect(() => {
    if (!startCounting) return
    
    let startTime: number | null = null
    const startValue = 0
    
    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime
      const progress = Math.min((currentTime - startTime) / duration, 1)
      
      // Easing function for smooth animation
      const easeOutQuart = 1 - Math.pow(1 - progress, 4)
      const currentValue = startValue + (end - startValue) * easeOutQuart
      
      setCount(currentValue)
      
      if (progress < 1) {
        requestAnimationFrame(animate)
      }
    }
    
    requestAnimationFrame(animate)
  }, [end, duration, startCounting])
  
  return count
}

function StatCard({ stat, index, isVisible }: { stat: typeof stats[0], index: number, isVisible: boolean }) {
  const count = useCountUp(stat.value, 2000, isVisible)
  const displayValue = stat.format ? formatNumber(Math.round(count)) : count.toFixed(stat.value % 1 !== 0 ? 1 : 0)
  
  return (
    <div 
      className="relative p-6 rounded-xl bg-card border border-border text-center group hover:border-primary/50 transition-all"
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
        <stat.icon className="w-7 h-7 text-primary" />
      </div>
      <div className="font-display text-3xl sm:text-4xl font-bold text-foreground mb-2">
        {displayValue}{stat.suffix}
      </div>
      <div className="text-sm text-muted-foreground">{stat.label}</div>
    </div>
  )
}

export function Stats() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.2 }
    )
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }
    
    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} id="istatistikler" className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-primary font-medium text-sm uppercase tracking-wider">İstatistikler</span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-foreground mt-3 mb-4">
            Rakamlarla Başarılar
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Yıllar içinde elde ettiğim başarılar ve ulaştığım rakamlar
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {stats.map((stat, index) => (
            <StatCard key={index} stat={stat} index={index} isVisible={isVisible} />
          ))}
        </div>
      </div>
    </section>
  )
}
