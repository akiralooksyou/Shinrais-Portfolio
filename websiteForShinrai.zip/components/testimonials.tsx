import { Quote } from "lucide-react"

const testimonials = [
  {
    name: "Ahmet Y.",
    role: "Oyun Stüdyosu Sahibi",
    content: "Profesyonelliği ve teknik becerisi ile projemizi bir üst seviyeye taşıdı. Kesinlikle tekrar çalışmak isterim.",
    avatar: "AY"
  },
  {
    name: "Zeynep K.",
    role: "İçerik Üreticisi",
    content: "Oyunumuz için harika bir script yazdı. İletişimi çok güçlü ve teslim süresine her zaman uyuyor.",
    avatar: "ZK"
  },
  {
    name: "Mert S.",
    role: "Indie Geliştirici",
    content: "DataStore sistemleri konusunda muhteşem bir uzmanlığa sahip. Oyunumuzun performansını inanılmaz artırdı.",
    avatar: "MS"
  },
  {
    name: "Elif D.",
    role: "Oyun Tasarımcısı",
    content: "UI/UX konusundaki önerileri projemize büyük değer kattı. Kreatif ve çözüm odaklı bir geliştirici.",
    avatar: "ED"
  },
]

export function Testimonials() {
  return (
    <section className="py-24 bg-card/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-primary font-medium text-sm uppercase tracking-wider">Referanslar</span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-foreground mt-3 mb-4">
            Müşteri Yorumları
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Birlikte çalıştığım kişilerin deneyimleri ve geri bildirimleri
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className="p-6 rounded-xl bg-background border border-border hover:border-primary/30 transition-colors"
            >
              <Quote className="w-10 h-10 text-primary/30 mb-4" />
              <p className="text-muted-foreground leading-relaxed mb-6">
                {'"'}{testimonial.content}{'"'}
              </p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold">
                  {testimonial.avatar}
                </div>
                <div>
                  <div className="font-medium text-foreground">{testimonial.name}</div>
                  <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
