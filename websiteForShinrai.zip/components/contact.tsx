"use client"

import { useState } from "react"
import { Send, Mail, MessageSquare, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

const socialLinks = [
  { name: "Discord", handle: "rblxdev#1234", icon: "💬" },
  { name: "Twitter/X", handle: "@rblxdev", icon: "𝕏" },
  { name: "Roblox", handle: "RblxDevOfficial", icon: "🎮" },
  { name: "GitHub", handle: "rblxdev", icon: "⚙️" },
]

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    setIsSubmitting(false)
    setSubmitted(true)
    setFormData({ name: "", email: "", message: "" })
    
    setTimeout(() => setSubmitted(false), 5000)
  }

  return (
    <section id="iletisim" className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-primary font-medium text-sm uppercase tracking-wider">İletişim</span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-foreground mt-3 mb-4">
            Benimle İletişime Geç
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Yeni projeler, işbirlikleri veya sorularınız için benimle iletişime geçebilirsiniz
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="p-8 rounded-xl bg-card border border-border">
            <h3 className="font-display font-semibold text-xl text-foreground mb-6">
              Mesaj Gönder
            </h3>
            
            {submitted ? (
              <div className="p-6 rounded-lg bg-primary/10 border border-primary/30 text-center">
                <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                  <Send className="w-8 h-8 text-primary" />
                </div>
                <h4 className="font-semibold text-foreground mb-2">Mesajınız Gönderildi!</h4>
                <p className="text-sm text-muted-foreground">
                  En kısa sürede size dönüş yapacağım.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Adınız
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      type="text"
                      placeholder="Adınızı girin"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    E-posta
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      type="email"
                      placeholder="E-posta adresinizi girin"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Mesajınız
                  </label>
                  <div className="relative">
                    <MessageSquare className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
                    <Textarea
                      placeholder="Projeniz hakkında bilgi verin..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="pl-10 min-h-[120px]"
                      required
                    />
                  </div>
                </div>
                
                <Button type="submit" className="w-full" disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2" />
                      Gönderiliyor...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Mesaj Gönder
                    </>
                  )}
                </Button>
              </form>
            )}
          </div>

          {/* Contact Info */}
          <div className="space-y-8">
            <div>
              <h3 className="font-display font-semibold text-xl text-foreground mb-4">
                Diğer İletişim Kanalları
              </h3>
              <p className="text-muted-foreground mb-6">
                Form yerine direkt olarak sosyal medya hesaplarımdan da bana ulaşabilirsiniz.
              </p>
              
              <div className="space-y-4">
                {socialLinks.map((link, index) => (
                  <div 
                    key={index}
                    className="flex items-center gap-4 p-4 rounded-lg bg-card border border-border hover:border-primary/30 transition-colors"
                  >
                    <div className="w-10 h-10 rounded-lg bg-secondary flex items-center justify-center text-lg">
                      {link.icon}
                    </div>
                    <div>
                      <div className="font-medium text-foreground">{link.name}</div>
                      <div className="text-sm text-muted-foreground">{link.handle}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-6 rounded-xl bg-primary/5 border border-primary/20">
              <h4 className="font-display font-semibold text-foreground mb-2">
                Hızlı Yanıt Garantisi
              </h4>
              <p className="text-sm text-muted-foreground">
                Tüm mesajlara genellikle 24 saat içinde yanıt veriyorum. 
                Acil projeler için Discord üzerinden ulaşmanızı öneririm.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
