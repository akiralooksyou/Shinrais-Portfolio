"use client"

import { useState } from "react"
import { ExternalLink, Users, Play, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

const projects = [
  {
    id: 1,
    title: "Survival Island",
    description: "Açık dünya hayatta kalma oyunu. Kaynak toplama, crafting ve multiplayer özelliklerle dolu.",
    image: "/projects/survival.jpg",
    category: "Hayatta Kalma",
    stats: { players: "2.5M+", visits: "15M+", rating: 4.8 },
    tags: ["Multiplayer", "Open World", "Crafting"],
    link: "#"
  },
  {
    id: 2,
    title: "Tower Defense Pro",
    description: "Strateji tabanlı kule savunma oyunu. 50+ farklı kule ve 100+ seviye.",
    image: "/projects/tower.jpg",
    category: "Strateji",
    stats: { players: "1.8M+", visits: "12M+", rating: 4.7 },
    tags: ["Strateji", "PvE", "Singleplayer"],
    link: "#"
  },
  {
    id: 3,
    title: "Racing Legends",
    description: "Hız tutkunları için araba yarışı oyunu. Özelleştirilebilir araçlar ve turnuvalar.",
    image: "/projects/racing.jpg",
    category: "Yarış",
    stats: { players: "3.2M+", visits: "20M+", rating: 4.9 },
    tags: ["Yarış", "Multiplayer", "Turnuva"],
    link: "#"
  },
  {
    id: 4,
    title: "Mystery Manor",
    description: "Gizem dolu bir konakta geçen dedektiflik oyunu. Bulmacalar ve hikaye odaklı.",
    image: "/projects/mystery.jpg",
    category: "Macera",
    stats: { players: "850K+", visits: "5M+", rating: 4.6 },
    tags: ["Hikaye", "Bulmaca", "Horror"],
    link: "#"
  },
  {
    id: 5,
    title: "Pet Simulator X",
    description: "Evcil hayvan toplama ve büyütme oyunu. Nadir petler ve ticaret sistemi.",
    image: "/projects/pet.jpg",
    category: "Simülasyon",
    stats: { players: "5M+", visits: "50M+", rating: 4.8 },
    tags: ["Simülasyon", "Koleksiyon", "Trading"],
    link: "#"
  },
  {
    id: 6,
    title: "Battle Royale Arena",
    description: "100 oyunculu battle royale deneyimi. Özel silahlar ve haritalar.",
    image: "/projects/battle.jpg",
    category: "Aksiyon",
    stats: { players: "4.1M+", visits: "30M+", rating: 4.7 },
    tags: ["Battle Royale", "PvP", "Competitive"],
    link: "#"
  },
]

const categories = ["Tümü", "Hayatta Kalma", "Strateji", "Yarış", "Macera", "Simülasyon", "Aksiyon"]

export function Projects() {
  const [activeCategory, setActiveCategory] = useState("Tümü")
  
  const filteredProjects = activeCategory === "Tümü" 
    ? projects 
    : projects.filter(p => p.category === activeCategory)

  return (
    <section id="projeler" className="py-24 bg-card/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <span className="text-primary font-medium text-sm uppercase tracking-wider">Projeler</span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-foreground mt-3 mb-4">
            Öne Çıkan Oyunlarım
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Geliştirdiğim ve milyonlarca oyuncuya ulaşan Roblox oyunları
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                activeCategory === category
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-muted-foreground hover:text-foreground"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project) => (
            <div 
              key={project.id}
              className="group rounded-xl bg-background border border-border overflow-hidden hover:border-primary/50 transition-all duration-300"
            >
              {/* Project Image Placeholder */}
              <div className="relative aspect-video bg-secondary overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                  <Play className="w-12 h-12 text-primary/50 group-hover:text-primary group-hover:scale-110 transition-all" />
                </div>
                <Badge className="absolute top-3 left-3 bg-background/80 text-foreground">
                  {project.category}
                </Badge>
              </div>
              
              {/* Project Info */}
              <div className="p-5">
                <h3 className="font-display font-semibold text-lg text-foreground mb-2 group-hover:text-primary transition-colors">
                  {project.title}
                </h3>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                  {project.description}
                </p>
                
                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map((tag, index) => (
                    <span 
                      key={index}
                      className="px-2 py-1 text-xs bg-secondary text-muted-foreground rounded"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                
                {/* Stats */}
                <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    <span>{project.stats.players}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Play className="w-4 h-4" />
                    <span>{project.stats.visits}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-500" />
                    <span>{project.stats.rating}</span>
                  </div>
                </div>
                
                <Button variant="outline" size="sm" className="w-full" asChild>
                  <a href={project.link} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Oyunu Görüntüle
                  </a>
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
