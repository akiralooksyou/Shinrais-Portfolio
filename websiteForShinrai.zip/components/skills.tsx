"use client"

const skillCategories = [
  {
    title: "Programlama",
    skills: [
      { name: "Lua", level: 95 },
      { name: "Roblox API", level: 92 },
      { name: "TypeScript", level: 75 },
      { name: "Python", level: 60 },
    ]
  },
  {
    title: "Oyun Geliştirme",
    skills: [
      { name: "Oyun Mekanikleri", level: 90 },
      { name: "Multiplayer Sistemler", level: 85 },
      { name: "UI/UX Tasarımı", level: 88 },
      { name: "Veri Yönetimi (DataStore)", level: 92 },
    ]
  },
  {
    title: "3D & Görsel",
    skills: [
      { name: "Roblox Studio", level: 95 },
      { name: "Blender", level: 70 },
      { name: "3D Modelleme", level: 75 },
      { name: "Aydınlatma & Efektler", level: 85 },
    ]
  },
  {
    title: "Araçlar & Diğer",
    skills: [
      { name: "Git & GitHub", level: 80 },
      { name: "Rojo", level: 85 },
      { name: "VS Code", level: 90 },
      { name: "Proje Yönetimi", level: 82 },
    ]
  },
]

export function Skills() {
  return (
    <section id="yetenekler" className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-primary font-medium text-sm uppercase tracking-wider">Yetenekler</span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-foreground mt-3 mb-4">
            Uzmanlık Alanlarım
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Yıllar içinde geliştirdiğim teknik beceriler ve uzmanlık alanlarım
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {skillCategories.map((category, categoryIndex) => (
            <div 
              key={categoryIndex}
              className="p-6 rounded-xl bg-card border border-border"
            >
              <h3 className="font-display font-semibold text-lg text-foreground mb-6">
                {category.title}
              </h3>
              <div className="space-y-5">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-foreground">{skill.name}</span>
                      <span className="text-sm text-primary font-medium">{skill.level}%</span>
                    </div>
                    <div className="h-2 bg-secondary rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-primary rounded-full transition-all duration-1000 ease-out"
                        style={{ width: `${skill.level}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
