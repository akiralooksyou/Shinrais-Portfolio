import { Gamepad2 } from "lucide-react"
import Link from "next/link"

const footerLinks = {
  navigation: [
    { label: "Hakkımda", href: "#hakkimda" },
    { label: "Yetenekler", href: "#yetenekler" },
    { label: "Projeler", href: "#projeler" },
    { label: "İstatistikler", href: "#istatistikler" },
    { label: "İletişim", href: "#iletisim" },
  ],
  social: [
    { label: "Discord", href: "#" },
    { label: "Twitter", href: "#" },
    { label: "Roblox", href: "#" },
    { label: "GitHub", href: "#" },
  ]
}

export function Footer() {
  return (
    <footer className="bg-card border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Gamepad2 className="w-6 h-6 text-primary" />
              </div>
              <span className="font-display text-xl font-bold text-foreground">
                RblxDev
              </span>
            </Link>
            <p className="text-muted-foreground text-sm max-w-sm">
              Profesyonel Roblox Studio geliştirici. Benzersiz oyun deneyimleri 
              tasarlıyor ve geliştiriyorum.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">Navigasyon</h4>
            <ul className="space-y-2">
              {footerLinks.navigation.map((link) => (
                <li key={link.href}>
                  <Link 
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Social */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">Sosyal Medya</h4>
            <ul className="space-y-2">
              {footerLinks.social.map((link) => (
                <li key={link.label}>
                  <a 
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} RblxDev. Tüm hakları saklıdır.
          </p>
          <p className="text-sm text-muted-foreground">
            Roblox ile yapıldı 🎮
          </p>
        </div>
      </div>
    </footer>
  )
}
