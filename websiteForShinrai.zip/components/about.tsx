import { Code2, Palette, Lightbulb, Users } from "lucide-react"

const highlights = [
  {
    icon: Code2,
    title: "Lua Scripting",
    description: "Karmaşık oyun mekanikleri ve sistemler geliştirme"
  },
  {
    icon: Palette,
    title: "Oyun Tasarımı",
    description: "Kullanıcı deneyimi odaklı yaratıcı tasarımlar"
  },
  {
    icon: Lightbulb,
    title: "Problem Çözme",
    description: "Teknik zorlukları yaratıcı çözümlerle aşma"
  },
  {
    icon: Users,
    title: "Takım Çalışması",
    description: "Farklı ekiplerle uyumlu ve verimli çalışma"
  },
]

export function About() {
  return (
    <section id="hakkimda" className="py-24 bg-card/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div>
            <span className="text-primary font-medium text-sm uppercase tracking-wider">Hakkımda</span>
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-foreground mt-3 mb-6">
              Tutkulu Bir Roblox Geliştirici
            </h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Merhaba! Ben Roblox Studio&apos;da oyun geliştirme konusunda uzmanlaşmış bir geliştiriciyim. 
                Yıllar içinde onlarca proje geliştirdim ve milyonlarca oyuncuya ulaşan deneyimler yarattım.
              </p>
              <p>
                Lua programlama dili, 3D modelleme, UI/UX tasarımı ve oyun mekanikleri konularında 
                derin bir bilgi birikimine sahibim. Her projede kalite ve oyuncu deneyimini ön planda tutuyorum.
              </p>
              <p>
                Yeni projeler için her zaman açığım. Eğer bir fikriniz varsa veya mevcut projenize 
                katkıda bulunmamı istiyorsanız, benimle iletişime geçmekten çekinmeyin!
              </p>
            </div>
          </div>
          
          {/* Right Content - Highlights Grid */}
          <div className="grid sm:grid-cols-2 gap-6">
            {highlights.map((item, index) => (
              <div 
                key={index}
                className="p-6 rounded-xl bg-background border border-border hover:border-primary/50 transition-colors group"
              >
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <item.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-display font-semibold text-foreground mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
